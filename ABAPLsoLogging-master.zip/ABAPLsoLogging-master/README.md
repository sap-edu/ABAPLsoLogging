# AbapLsoLogging
Logging Messages with Traces and shared Payload Storage

Is required by https://github.wdf.sap.corp/D045459/AbapTransportNotifier
